export { default as Home } from './Home';
export { default as Sales } from './Sales';
export { default as Featured } from './Featured';
export { default as Stories } from './Stories';
export { default as Footer } from './Footer';
export { default as Navbar } from './Navbar'
export { default as Cart } from './Cart';